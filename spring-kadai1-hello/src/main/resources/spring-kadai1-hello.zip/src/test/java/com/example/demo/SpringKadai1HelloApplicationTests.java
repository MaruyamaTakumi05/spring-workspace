package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringKadai1HelloApplicationTests {

	@Test
	void contextLoads() {
	}

}
