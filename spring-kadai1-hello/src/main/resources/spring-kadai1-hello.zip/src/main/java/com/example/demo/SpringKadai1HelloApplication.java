package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringKadai1HelloApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringKadai1HelloApplication.class, args);
	}

}
