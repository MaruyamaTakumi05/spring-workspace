package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringKadai5JpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringKadai5JpaApplication.class, args);
	}

}
